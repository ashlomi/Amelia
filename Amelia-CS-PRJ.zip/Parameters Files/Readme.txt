echo "# Discovery-Releases" >> README.md
git init
git add README.md
git commit -m "first commit"
git remote add origin https://github.com/ashlomi/Discovery-Releases.git
git push -u origin master
