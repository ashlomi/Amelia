/**
 * Get the domain name to load environment dynamic
 * @param id
 * @return domain name
 */
def indentifyDomainName(id) {
    
    id = id.toLowerCase()
    
    def domains = [
            "playground" : "c87f3edd-b7f4-4f80-beff-ebc0d2e7f251",
            "dev": "2459f37b-8d9a-4467-b11d-7aa199ac6295",
            "preprod": "ee0c0d34-cc61-4ceb-ab46-fa58d2b674fe",
            "stage": "c887a01a-5ef2-4ffc-8030-bc1a8a1ecd7a",
            "prod": "1dcb0997-5d82-45e5-9ecd-ccaca53e36aa",
    ]

    for(item in domains) {
        if (item.value == id) {
            return item.key
        }
    }
}